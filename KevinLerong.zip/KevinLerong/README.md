I got all of the code from part one written how I think it should be working,

but I could not get even one object and one light to render properly and I do not know what else to do to debug it.

part 2 is semi complete with materials and lights in the scene. 

I would like to get some advice on how to debug this problem.